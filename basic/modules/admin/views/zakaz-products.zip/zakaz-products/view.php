<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model app\modules\admin\models\ZakazProducts */

$this->title = $model->ProductName;
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Заказные товары'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="zakaz-products-view">

    <h1><?= Html::encode($this->title) ?> Поставщик: <i><?= $model->Supplier ?></i></h1>

    <p>
        <?= Html::a(Yii::t('app', 'Редактировать'), ['update', 'id' => $model->Id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a(Yii::t('app', 'Удалить'), ['delete', 'id' => $model->Id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => Yii::t('app', 'Вы действительно хотите удалить данную позицию?'),
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            // 'Id',
            'Supplier',
            'Brand',
            'ProductName',
            'Description',
            'EntryPrice',
            'Markup',
            'Price',
            'TermsDelive',
            [
                'attribute' => 'Img',
                'value' =>  $model->Img,
                'format' => ['image', ['class' => 'img adminBrend rounded mx-auto d-block']],

            ],
            'Count',
        ],
    ]) ?>

</div>