<?php

/** @var $this \yii\web\View */
/** @var $link string */
/** @var $paramExample string */

?>
Текст письма...

Переданный параметр: <?= $paramExample ?>