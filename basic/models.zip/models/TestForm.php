<?
namespace app\models;
use yii\base\Model;

class TestForm extends Model{
    
}

?>